import java.io.BufferedReader;
import java.io.BufferedWriter;

/**
 * Created by Lexx on 04.09.2015.
 */
public class Main {
    BufferedReader in;
    BufferedWriter out;

    public static void main(String[] args) {

    }

}
